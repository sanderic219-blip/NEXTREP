import React from "react";
import { 
  useListTrainingVideos, 
  useToggleTrainingVideoLike,
  useToggleTrainingVideoSave,
  useAddTrainingVideoToWorkout,
  useCompleteWorkout,
  getListTrainingVideosQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, Button, Badge, Skeleton, Tabs, TabsList, TabsTrigger } from "@/components/ui";
import { Play, Heart, Bookmark, Share2, ShieldCheck, Dumbbell, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function TrainPage() {
  const [category, setCategory] = React.useState<string>("for-you");
  const { data: videos, isLoading } = useListTrainingVideos({ category: category === "for-you" ? undefined : category });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const likeMutation = useToggleTrainingVideoLike();
  const saveMutation = useToggleTrainingVideoSave();
  const addWorkoutMutation = useAddTrainingVideoToWorkout();
  const completeMutation = useCompleteWorkout();

  const handleLike = (id: number) => {
    likeMutation.mutate({ videoId: id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTrainingVideosQueryKey() });
      }
    });
  };

  const handleSave = (id: number) => {
    saveMutation.mutate({ videoId: id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListTrainingVideosQueryKey() });
      }
    });
  };

  const handleAddWorkout = (id: number) => {
    addWorkoutMutation.mutate({ videoId: id }, {
      onSuccess: (workoutItem) => {
        toast({
          title: "Added to Workout",
          description: `${workoutItem.title} queued up.`,
        });
        // We'll immediately complete it for the demo flow feeling "fast"
        handleCompleteWorkout(workoutItem.id);
      }
    });
  };

  const handleCompleteWorkout = (workoutId: number) => {
    completeMutation.mutate({ workoutId }, {
      onSuccess: (res) => {
        toast({
          title: "Workout Completed!",
          description: `+${res.xpEarned} XP. Rep Score is now ${res.newRepScore}. ${res.message}`,
        });
      }
    });
  };

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex flex-col md:flex-row justify-between md:items-end gap-4">
        <div>
          <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-foreground">
            Training Lab
          </h1>
          <p className="text-muted-foreground font-medium text-lg mt-1">
            Short-form drills. Real coaches. Measurable improvement.
          </p>
        </div>
        
        <Tabs defaultValue="for-you" onValueChange={setCategory} className="w-full md:w-auto">
          <TabsList className="w-full md:w-auto grid grid-cols-3">
            <TabsTrigger value="for-you">For You</TabsTrigger>
            <TabsTrigger value="drills">Drills</TabsTrigger>
            <TabsTrigger value="strength">Strength</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => <Skeleton key={i} className="h-96 rounded-2xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos?.map((vid) => (
            <Card key={vid.id} className="overflow-hidden group flex flex-col h-full bg-card border-2 hover:border-primary transition-colors">
              <div 
                className="relative aspect-[4/5] bg-cover bg-center flex items-center justify-center"
                style={{ 
                  backgroundImage: vid.thumbnailUrl ? `url(${vid.thumbnailUrl})` : undefined,
                  background: vid.gradient ? vid.gradient : undefined 
                }}
              >
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors" />
                <Button variant="secondary" size="icon" className="w-16 h-16 rounded-full opacity-90 group-hover:scale-110 transition-all shadow-xl">
                  <Play className="w-8 h-8 ml-1" />
                </Button>
                
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  <Badge className="bg-black/60 text-white backdrop-blur-sm border-none shadow-sm">{vid.difficulty}</Badge>
                  <Badge variant="outline" className="bg-black/60 text-white backdrop-blur-sm border-none shadow-sm">{vid.duration}</Badge>
                </div>
              </div>
              
              <CardContent className="p-5 flex-1 flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-bold text-xl leading-tight line-clamp-2">{vid.drillName}</h3>
                    <div className="text-sm font-bold text-muted-foreground mt-1 flex items-center gap-1">
                      {vid.coach} {vid.verified && <ShieldCheck className="w-4 h-4 text-primary" />}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 mt-auto pt-4 border-t">
                  <button 
                    onClick={() => handleLike(vid.id)} 
                    className={`flex items-center gap-1 text-sm font-bold transition-colors ${vid.liked ? 'text-destructive' : 'text-muted-foreground hover:text-foreground'}`}
                  >
                    <Heart className="w-5 h-5" fill={vid.liked ? "currentColor" : "none"} />
                    <span className="font-mono">{vid.likes}</span>
                  </button>
                  <button 
                    onClick={() => handleSave(vid.id)} 
                    className={`flex items-center gap-1 text-sm font-bold transition-colors ${vid.saved ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
                  >
                    <Bookmark className="w-5 h-5" fill={vid.saved ? "currentColor" : "none"} />
                  </button>
                  <button className="flex items-center gap-1 text-sm font-bold text-muted-foreground hover:text-foreground">
                    <Share2 className="w-5 h-5" />
                  </button>

                  <div className="ml-auto">
                    <Button 
                      size="sm" 
                      onClick={() => handleAddWorkout(vid.id)}
                      disabled={addWorkoutMutation.isPending}
                    >
                      <Dumbbell className="w-4 h-4 mr-2" /> Do It
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {videos?.length === 0 && (
            <div className="col-span-full text-center py-20 bg-muted/50 rounded-2xl">
              <Dumbbell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-bold">No videos found</h3>
              <p className="text-muted-foreground">Check back later for new drills.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
