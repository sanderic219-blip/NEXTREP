import React, { useRef, useEffect } from "react";
import { 
  useGetCoachRecommendation,
  useSendCoachMessage
} from "@workspace/api-client-react";
import { Card, CardContent, Button, Input, Avatar, Skeleton } from "@/components/ui";
import { Send, Bot, User, Flame } from "lucide-react";
import { type CoachMessage } from "@workspace/api-client-react";

export default function CoachPage() {
  const { data: rec, isLoading: isRecLoading } = useGetCoachRecommendation();
  const sendMessageMutation = useSendCoachMessage();
  const [messages, setMessages] = React.useState<CoachMessage[]>([]);
  const [input, setInput] = React.useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || sendMessageMutation.isPending) return;

    const userMsg: CoachMessage = {
      id: Date.now(),
      role: "user",
      message: input,
      createdAt: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput("");

    sendMessageMutation.mutate({ data: { message: userMsg.message } }, {
      onSuccess: (reply) => {
        setMessages(prev => [...prev, reply]);
      }
    });
  };

  return (
    <div className="h-[calc(100vh-140px)] md:h-[calc(100vh-80px)] flex flex-col gap-6 animate-slide-in-right">
      
      {/* Top Rec */}
      {!isRecLoading && rec && (
        <Card className="shrink-0 bg-primary text-primary-foreground border-none">
          <CardContent className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-white/10 rounded-full shrink-0">
                <Flame className="w-8 h-8 text-secondary" />
              </div>
              <div>
                <div className="text-sm font-bold uppercase tracking-widest text-primary-foreground/80 mb-1">{rec.eyebrow}</div>
                <h3 className="text-xl font-bold">{rec.title}</h3>
                <p className="text-primary-foreground/90 font-medium max-w-2xl">{rec.body}</p>
              </div>
            </div>
            <Button variant="secondary" className="shrink-0 font-bold uppercase tracking-wider">
              {rec.cta}
            </Button>
          </CardContent>
        </Card>
      )}

      {isRecLoading && <Skeleton className="h-32 w-full shrink-0" />}

      {/* Chat Area */}
      <Card className="flex-1 flex flex-col overflow-hidden border-2">
        <div className="bg-muted p-4 border-b flex items-center gap-3">
          <Avatar fallback="AI" className="bg-primary text-primary-foreground" />
          <div>
            <h2 className="font-bold text-foreground">Coach AI</h2>
            <p className="text-xs font-bold text-muted-foreground uppercase">Always Online</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6" ref={scrollRef}>
          <div className="text-center">
            <span className="bg-muted text-muted-foreground text-xs font-bold uppercase px-3 py-1 rounded-full">
              Today
            </span>
          </div>

          <div className="flex gap-3 max-w-[80%]">
            <Avatar fallback="AI" className="bg-primary text-primary-foreground shrink-0 w-8 h-8" />
            <div className="bg-muted text-foreground p-3 rounded-2xl rounded-tl-sm text-sm font-medium">
              Ready to work? Ask me about adjusting your routine, dealing with soreness, or specific drills for your position.
            </div>
          </div>

          {messages.map((m) => {
            const isUser = m.role === "user";
            return (
              <div key={m.id} className={`flex gap-3 max-w-[80%] ${isUser ? 'ml-auto flex-row-reverse' : ''}`}>
                <Avatar 
                  fallback={isUser ? "U" : "AI"} 
                  className={`shrink-0 w-8 h-8 ${isUser ? 'bg-secondary text-secondary-foreground' : 'bg-primary text-primary-foreground'}`} 
                />
                <div className={`p-3 rounded-2xl text-sm font-medium ${
                  isUser 
                    ? 'bg-primary text-primary-foreground rounded-tr-sm' 
                    : 'bg-muted text-foreground rounded-tl-sm'
                }`}>
                  {m.message}
                </div>
              </div>
            );
          })}
          
          {sendMessageMutation.isPending && (
            <div className="flex gap-3 max-w-[80%]">
              <Avatar fallback="AI" className="bg-primary text-primary-foreground shrink-0 w-8 h-8" />
              <div className="bg-muted text-muted-foreground p-3 rounded-2xl rounded-tl-sm flex gap-1 items-center">
                <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce"></span>
                <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-card">
          <form onSubmit={handleSend} className="flex gap-2">
            <Input 
              placeholder="Ask Coach AI..." 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 rounded-full bg-muted border-none focus-visible:ring-primary h-12 px-6 font-medium"
              disabled={sendMessageMutation.isPending}
            />
            <Button 
              type="submit" 
              size="icon" 
              className="rounded-full h-12 w-12 shrink-0 bg-primary"
              disabled={!input.trim() || sendMessageMutation.isPending}
            >
              <Send className="w-5 h-5 ml-1" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  );
}
