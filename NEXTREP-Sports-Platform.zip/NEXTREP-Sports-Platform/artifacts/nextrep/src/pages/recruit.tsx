import React from "react";
import { useGetAthleteProfile } from "@workspace/api-client-react";
import { Card, CardContent, Badge, Skeleton, Button } from "@/components/ui";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Share2, MapPin, GraduationCap, Copy, ExternalLink, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function RecruitPage() {
  const { data: profile, isLoading } = useGetAthleteProfile();
  const { toast } = useToast();

  if (isLoading) {
    return <Skeleton className="h-[600px] w-full max-w-3xl mx-auto rounded-3xl" />;
  }

  if (!profile) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(`https://nextrep.app/recruit/${profile.id}`);
    toast({ title: "Link Copied!", description: "Recruiting profile link ready to share." });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-slide-up pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tight">Digital Profile</h1>
          <p className="text-muted-foreground font-medium">Your shareable athletic resume.</p>
        </div>
        <Button onClick={handleCopy} className="hidden md:flex gap-2">
          <Copy className="w-4 h-4" /> Copy Link
        </Button>
      </div>

      <Card className="overflow-hidden border-2 shadow-xl bg-card">
        {/* Banner Area */}
        <div className="h-48 bg-gradient-to-br from-primary to-blue-900 relative">
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white to-transparent" />
          <div className="absolute top-4 right-4 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2">
            <Activity className="w-3 h-3" /> NEXTREP VERIFIED
          </div>
        </div>

        {/* Profile Info */}
        <div className="px-6 md:px-10 pb-10 relative">
          <div className="flex flex-col md:flex-row md:items-end gap-6 -mt-16 mb-6">
            <Avatar className="w-32 h-32 border-4 border-card shadow-lg bg-muted">
              <AvatarImage src={profile.avatarUrl} alt={profile.name} />
              <AvatarFallback className="text-4xl font-black">{profile.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1 pb-2">
              <h2 className="text-4xl font-black tracking-tight leading-none mb-1">{profile.name}</h2>
              <div className="flex flex-wrap items-center gap-2 text-muted-foreground font-bold">
                <Badge variant="rep">{profile.position}</Badge>
                <span>&bull;</span>
                <span>{profile.sport}</span>
              </div>
            </div>
            <div className="hidden md:block pb-2 text-right">
              <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Rep Score</div>
              <div className="text-4xl font-black font-mono text-secondary">{profile.repScore}</div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-muted p-3 rounded-lg text-center">
              <MapPin className="w-5 h-5 mx-auto mb-1 text-primary" />
              <div className="text-xs font-bold uppercase text-muted-foreground">Location</div>
              <div className="font-bold line-clamp-1">{profile.location}</div>
            </div>
            <div className="bg-muted p-3 rounded-lg text-center">
              <GraduationCap className="w-5 h-5 mx-auto mb-1 text-primary" />
              <div className="text-xs font-bold uppercase text-muted-foreground">Class</div>
              <div className="font-bold">{profile.graduationYear}</div>
            </div>
            <div className="bg-muted p-3 rounded-lg text-center">
              <div className="text-xl font-black font-mono text-primary mb-1 leading-none">{profile.gpa}</div>
              <div className="text-xs font-bold uppercase text-muted-foreground">GPA</div>
              <div className="font-bold">{profile.school}</div>
            </div>
            <div className="bg-muted p-3 rounded-lg text-center">
              <div className="text-xl font-black font-mono text-primary mb-1 leading-none">{profile.height}</div>
              <div className="text-xs font-bold uppercase text-muted-foreground">Height / Wt</div>
              <div className="font-bold">{profile.weight}</div>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-black uppercase tracking-tight mb-3 border-b pb-2">Athletic Metrics</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {profile.stats.map((stat, i) => (
                  <div key={i} className="flex justify-between items-center p-3 border rounded-lg">
                    <span className="font-bold text-muted-foreground">{stat.label}</span>
                    <span className="font-black font-mono text-lg">{stat.value}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-black uppercase tracking-tight mb-3 border-b pb-2">Key Achievements</h3>
              <div className="space-y-3">
                {profile.achievements.map((ach, i) => (
                  <div key={i} className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                    <div className="text-2xl mt-1">{ach.icon}</div>
                    <div>
                      <div className="font-bold">{ach.title}</div>
                      <div className="text-sm font-medium text-muted-foreground">{ach.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Button onClick={handleCopy} size="lg" className="w-full md:hidden flex gap-2 mt-4">
        <Share2 className="w-5 h-5" /> Share Profile
      </Button>
    </div>
  );
}
