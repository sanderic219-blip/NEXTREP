import React from "react";
import { useGetAthleteProgress } from "@workspace/api-client-react";
import { Card, CardContent, Progress, Skeleton, Badge } from "@/components/ui";
import { TrendingUp, Trophy, Target, ArrowUpRight } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";

export default function ProgressPage() {
  const { data: progress, isLoading } = useGetAthleteProgress();

  if (isLoading) {
    return (
      <div className="space-y-8">
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-80 w-full" />
      </div>
    );
  }

  if (!progress) return <div>Failed to load progress.</div>;

  const isPositive = progress.scoreChange >= 0;

  return (
    <div className="space-y-8 animate-slide-up">
      <div>
        <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-foreground">
          Performance Data
        </h1>
        <p className="text-muted-foreground font-medium text-lg mt-1">
          Numbers don't lie. Track your growth.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 md:col-span-3 border-2 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <TrendingUp className="w-48 h-48" />
          </div>
          <CardContent className="p-8 md:p-10 relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <div className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-2">Current Rep Score</div>
              <div className="text-6xl md:text-8xl font-black font-mono text-primary leading-none tracking-tighter">
                {progress.repScore}
              </div>
              <div className={`mt-4 inline-flex items-center gap-1 font-bold text-lg px-4 py-1 rounded-full ${isPositive ? 'bg-secondary/10 text-secondary' : 'bg-destructive/10 text-destructive'}`}>
                {isPositive ? <ArrowUpRight className="w-5 h-5" /> : <TrendingUp className="w-5 h-5 rotate-180" />}
                {isPositive ? '+' : ''}{progress.scoreChange} this week
              </div>
            </div>

            <div className="w-full md:w-2/3 h-48 md:h-64 mt-4 md:mt-0">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={progress.weeklyActivity} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))', fontWeight: 'bold' }} dy={10} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: 'var(--shadow-md)', fontWeight: 'bold' }}
                    itemStyle={{ color: 'hsl(var(--primary))' }}
                  />
                  <Area type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={4} fillOpacity={1} fill="url(#colorValue)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <h2 className="text-2xl font-black uppercase tracking-tight flex items-center gap-2">
            <Target className="w-6 h-6 text-secondary" /> Personal Records
          </h2>
          <div className="grid gap-3">
            {progress.personalRecords.map((pr, i) => (
              <Card key={i} className="hover:border-secondary transition-colors group">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="font-bold text-lg">{pr.label}</div>
                  <div className="text-right">
                    <div className="font-mono text-xl font-black text-foreground">{pr.value}</div>
                    <div className="text-xs font-bold text-secondary">{pr.change}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-black uppercase tracking-tight flex items-center gap-2">
            <Trophy className="w-6 h-6 text-primary" /> Recent Wins
          </h2>
          <Card>
            <CardContent className="p-0 divide-y">
              {progress.recentWins.map((win, i) => (
                <div key={i} className="p-5 flex gap-4 items-start hover:bg-muted/30 transition-colors">
                  <div className="bg-primary/10 p-2 rounded-full text-primary shrink-0">
                    <Trophy className="w-5 h-5" />
                  </div>
                  <div className="font-bold text-lg leading-tight mt-1">{win}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
