import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function HomePage() {
  return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center bg-background px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('/wallpapers/football.jpg')] bg-cover bg-center opacity-30 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      
      <div className="relative z-10 w-full max-w-3xl text-center space-y-8 animate-slide-up">
        <div className="flex flex-col items-center gap-4">
          <img src="/logo.svg" alt="NEXTREP Logo" className="w-32 md:w-48 mx-auto shadow-2xl rounded-full" />
          <h1 className="text-4xl md:text-7xl font-black uppercase tracking-tighter text-foreground drop-shadow-sm">
            Own Your <span className="text-primary">Next Rep</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground font-medium max-w-2xl mt-4">
            Train hard. Track progress. Get recruited. No excuses.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
          <Button size="lg" className="w-full sm:w-auto h-14 text-lg font-bold px-10 shadow-lg hover:scale-105 transition-transform" asChild>
            <Link href="/sign-up">Start Training</Link>
          </Button>
          <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 text-lg font-bold px-10 border-2" asChild>
            <Link href="/sign-in">Sign In</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
