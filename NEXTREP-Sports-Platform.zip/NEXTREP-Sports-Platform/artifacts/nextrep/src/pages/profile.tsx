import React from "react";
import { useGetAthleteProfile, useUpdateAthleteProfile, getGetAthleteProfileQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, Button, Input, Skeleton } from "@/components/ui";
import { UserCircle, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const profileSchema = z.object({
  name: z.string().min(2),
  sport: z.string().min(2),
  position: z.string().min(1),
  graduationYear: z.coerce.number().min(2020).max(2030),
  height: z.string(),
  weight: z.string(),
  school: z.string(),
  location: z.string(),
  gpa: z.coerce.number().min(0).max(5),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilePage() {
  const { data: profile, isLoading } = useGetAthleteProfile();
  const updateMutation = useUpdateAthleteProfile();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: "", sport: "", position: "", graduationYear: 2025, height: "", weight: "", school: "", location: "", gpa: 0
    }
  });

  React.useEffect(() => {
    if (profile) {
      form.reset({
        name: profile.name,
        sport: profile.sport,
        position: profile.position,
        graduationYear: profile.graduationYear,
        height: profile.height,
        weight: profile.weight,
        school: profile.school,
        location: profile.location,
        gpa: profile.gpa,
      });
    }
  }, [profile, form]);

  if (isLoading) return <Skeleton className="h-[600px] w-full rounded-2xl" />;
  if (!profile) return null;

  const onSubmit = (data: ProfileFormValues) => {
    updateMutation.mutate({ data }, {
      onSuccess: () => {
        toast({ title: "Profile Updated", description: "Your changes have been saved." });
        queryClient.invalidateQueries({ queryKey: getGetAthleteProfileQueryKey() });
      }
    });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-slide-up">
      <div>
        <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-foreground">
          Account Settings
        </h1>
        <p className="text-muted-foreground font-medium text-lg mt-1">
          Manage your personal and athletic details.
        </p>
      </div>

      <Card>
        <CardContent className="p-6 md:p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              <div className="space-y-4">
                <h3 className="text-xl font-bold uppercase tracking-tight border-b pb-2 flex items-center gap-2">
                  <UserCircle className="w-5 h-5 text-primary" /> Basic Info
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="location" render={({ field }) => (
                    <FormItem><FormLabel>Location</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold uppercase tracking-tight border-b pb-2 mt-8">Athletic Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <FormField control={form.control} name="sport" render={({ field }) => (
                    <FormItem><FormLabel>Sport</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="position" render={({ field }) => (
                    <FormItem><FormLabel>Position</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="height" render={({ field }) => (
                    <FormItem><FormLabel>Height</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="weight" render={({ field }) => (
                    <FormItem><FormLabel>Weight</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold uppercase tracking-tight border-b pb-2 mt-8">Academics</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField control={form.control} name="school" render={({ field }) => (
                    <FormItem className="md:col-span-2"><FormLabel>School</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="graduationYear" render={({ field }) => (
                    <FormItem><FormLabel>Class Of</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                  <FormField control={form.control} name="gpa" render={({ field }) => (
                    <FormItem><FormLabel>GPA</FormLabel><FormControl><Input type="number" step="0.1" {...field} /></FormControl><FormMessage /></FormItem>
                  )} />
                </div>
              </div>

              <div className="pt-4 flex justify-end">
                <Button type="submit" size="lg" disabled={updateMutation.isPending} className="w-full md:w-auto">
                  <Save className="w-5 h-5 mr-2" /> Save Changes
                </Button>
              </div>

            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
