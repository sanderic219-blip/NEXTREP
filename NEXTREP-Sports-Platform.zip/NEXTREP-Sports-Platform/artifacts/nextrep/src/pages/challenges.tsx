import React from "react";
import { useListChallenges, useListLeaderboard } from "@workspace/api-client-react";
import { Card, CardContent, Progress, Avatar, Skeleton, Tabs, TabsList, TabsTrigger, TabsContent, Badge, Button } from "@/components/ui";
import { Trophy, Medal, Timer, Swords } from "lucide-react";

export default function ChallengesPage() {
  const { data: challenges, isLoading: loadingChallenges } = useListChallenges();
  const { data: leaderboard, isLoading: loadingLeaderboard } = useListLeaderboard();

  return (
    <div className="space-y-8 animate-slide-up">
      <div>
        <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-foreground flex items-center gap-3">
          <Swords className="w-10 h-10 text-secondary" /> Compete
        </h1>
        <p className="text-muted-foreground font-medium text-lg mt-1">
          Push your limits against the community.
        </p>
      </div>

      <Tabs defaultValue="challenges" className="w-full">
        <TabsList className="w-full max-w-sm grid grid-cols-2 mb-8">
          <TabsTrigger value="challenges">Active Challenges</TabsTrigger>
          <TabsTrigger value="leaderboard">Global Leaderboard</TabsTrigger>
        </TabsList>

        <TabsContent value="challenges">
          {loadingChallenges ? (
            <div className="grid gap-4"><Skeleton className="h-40" /><Skeleton className="h-40" /></div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {challenges?.map((c) => (
                <Card key={c.id} className="border-2 border-transparent hover:border-primary transition-colors">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold">{c.title}</h3>
                        <p className="text-muted-foreground font-medium mt-1 line-clamp-2">{c.description}</p>
                      </div>
                      <Badge variant="outline" className="flex items-center gap-1 font-mono">
                        <Timer className="w-3 h-3" /> {c.endsIn}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2 mt-6">
                      <div className="flex justify-between text-sm font-bold">
                        <span>Progress</span>
                        <span className="font-mono">{c.progress} / {c.target}</span>
                      </div>
                      <Progress value={(c.progress / c.target) * 100} className="h-3" colorClass="bg-secondary" />
                    </div>
                    
                    <div className="mt-6 pt-4 border-t flex items-center justify-between">
                      <div className="text-sm font-bold text-muted-foreground">
                        Reward: <span className="text-primary">{c.reward}</span>
                      </div>
                      <Button size="sm" variant="ghost-sport">Join Challenge</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="leaderboard">
          <Card className="overflow-hidden border-2 shadow-sm">
            {loadingLeaderboard ? (
              <div className="p-6 space-y-4">
                {[1,2,3,4].map(i => <Skeleton key={i} className="h-16" />)}
              </div>
            ) : (
              <CardContent className="p-0 divide-y">
                {leaderboard?.map((entry) => (
                  <div 
                    key={entry.rank} 
                    className={`flex items-center gap-4 p-4 md:p-6 transition-colors ${entry.isCurrentUser ? 'bg-primary/5' : 'hover:bg-muted/30'}`}
                  >
                    <div className="w-12 text-center">
                      {entry.rank === 1 ? <Medal className="w-8 h-8 text-yellow-500 mx-auto" /> :
                       entry.rank === 2 ? <Medal className="w-8 h-8 text-gray-400 mx-auto" /> :
                       entry.rank === 3 ? <Medal className="w-8 h-8 text-amber-700 mx-auto" /> :
                       <span className="text-xl font-black text-muted-foreground">{entry.rank}</span>}
                    </div>
                    
                    <Avatar src={entry.avatarUrl} alt={entry.name} className="w-12 h-12 border-2 border-background shadow-sm" />
                    
                    <div className="flex-1">
                      <div className="font-bold text-lg flex items-center gap-2">
                        {entry.name}
                        {entry.isCurrentUser && <Badge className="h-5 px-1.5 text-[10px]">YOU</Badge>}
                      </div>
                      <div className="text-sm font-bold text-muted-foreground">{entry.position}</div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-2xl font-black font-mono text-primary">{entry.score}</div>
                      <div className={`text-xs font-bold ${entry.change > 0 ? 'text-secondary' : 'text-muted-foreground'}`}>
                        {entry.change > 0 ? '+' : ''}{entry.change} pts
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
