import { SignUp } from '@clerk/react';
import React from 'react';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

export default function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 py-8 relative">
      <div className="absolute inset-0 bg-[url('/wallpapers/stadium.jpg')] bg-cover bg-center opacity-20 pointer-events-none" />
      <div className="relative z-10 w-full max-w-md flex flex-col items-center">
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
      </div>
    </div>
  );
}
