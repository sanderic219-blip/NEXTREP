import React from "react";
import { Link } from "wouter";
import { 
  useGetDashboard,
  useGetPersonalization
} from "@workspace/api-client-react";
import { Card, CardContent, Progress, Button, Skeleton, Badge } from "@/components/ui";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Activity, Flame, Calendar, ChevronRight, PlaySquare, Settings } from "lucide-react";
import { CustomizationDialog } from "@/components/customization/CustomizationDialog";
import { DailyMindset } from "@/components/mindset/DailyMindset";

export default function DashboardPage() {
  const { data: dash, isLoading, error } = useGetDashboard();
  const { data: personalization } = useGetPersonalization();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-48 w-full rounded-2xl" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <Skeleton className="h-64 rounded-xl" />
      </div>
    );
  }

  if (error || !dash) {
    return <div className="text-center py-20 font-bold text-muted-foreground">Failed to load dashboard.</div>;
  }

  const getWallpaperPath = (wp?: string | null) => {
    if (!wp) return "/wallpapers/football.jpg";
    if (wp.startsWith('/api')) return wp;
    if (wp.startsWith('http')) return wp;
    return `/wallpapers/${wp}${wp.startsWith('nextrep-') ? '.svg' : '.jpg'}`;
  };

  const wallpaperPath = getWallpaperPath(personalization?.wallpaper);

  const avatarUrl = personalization?.avatarUrl || dash.athlete.avatarUrl;

  return (
    <div className="space-y-8 animate-slide-up pb-8">
      {/* Hero Welcome */}
      <div className="relative rounded-3xl overflow-hidden shadow-lg border-2 border-border/50">
        <div className="absolute inset-0">
          <img src={wallpaperPath} alt="Dashboard Background" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/40 to-transparent" />
        </div>
        
        <div className="relative p-6 md:p-10 flex flex-col md:flex-row md:items-end justify-between gap-6 pt-24 md:pt-32">
          <div className="flex items-center gap-6">
            <div className="relative group">
              <Avatar className="h-20 w-20 md:h-24 md:w-24 ring-4 ring-primary ring-offset-4 ring-offset-background shadow-xl">
                <AvatarImage src={avatarUrl} alt={dash.athlete.firstName} />
                <AvatarFallback className="text-3xl font-black bg-muted text-muted-foreground">
                  {dash.athlete.firstName.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <CustomizationDialog>
                <button className="absolute -bottom-2 -right-2 bg-primary text-primary-foreground p-2 rounded-full shadow-lg hover:scale-110 transition-transform">
                  <Settings className="w-4 h-4" />
                </button>
              </CustomizationDialog>
            </div>
            <div>
              <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-foreground drop-shadow-sm">
                Let's Go, <br className="md:hidden" />
                <span className="text-primary">{dash.athlete.firstName}</span>
              </h1>
              <p className="text-foreground/90 font-medium text-lg flex items-center gap-2 mt-1">
                <span className="font-mono font-bold bg-primary/20 px-2 py-0.5 rounded text-primary">{dash.athlete.position}</span>
                <span className="font-bold opacity-80">&bull;</span>
                <span className="font-bold uppercase tracking-wider text-sm opacity-90">{dash.athlete.sport}</span>
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4 bg-card/80 backdrop-blur-md p-3 pr-8 rounded-full border border-white/10 shadow-sm w-max">
            <div className="bg-secondary text-secondary-foreground w-12 h-12 rounded-full flex items-center justify-center font-black">
              REP
            </div>
            <div>
              <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Rep Score</div>
              <div className="font-mono text-2xl font-black text-foreground">{dash.stats.repScore}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-primary text-primary-foreground border-none shadow-md">
          <CardContent className="p-4 md:p-6 flex flex-col justify-between h-full">
            <Flame className="w-6 h-6 text-primary-foreground/70 mb-2" />
            <div>
              <div className="text-3xl font-black font-mono">{dash.stats.streak}</div>
              <div className="text-sm font-bold uppercase tracking-wider opacity-90">Day Streak</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm">
          <CardContent className="p-4 md:p-6 flex flex-col justify-between h-full">
            <Activity className="w-6 h-6 text-muted-foreground mb-2" />
            <div>
              <div className="text-3xl font-black font-mono text-foreground">{dash.stats.workoutsCompleted}</div>
              <div className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Workouts</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="col-span-2 md:col-span-2 shadow-sm">
          <CardContent className="p-4 md:p-6 h-full flex flex-col justify-center">
            <div className="flex justify-between items-end mb-2">
              <div>
                <div className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-1">Weekly Goal</div>
                <div className="font-black text-xl">{dash.weeklyGoal.label}</div>
              </div>
              <div className="text-right font-mono font-bold">
                <span className="text-primary text-2xl">{dash.weeklyGoal.completed}</span>
                <span className="text-muted-foreground text-lg">/{dash.weeklyGoal.target}</span>
              </div>
            </div>
            <Progress value={(dash.weeklyGoal.completed / dash.weeklyGoal.target) * 100} className="h-4" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Feed area */}
        <div className="lg:col-span-2 space-y-6">
          <div className="md:hidden">
            <DailyMindset />
          </div>

          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black uppercase tracking-tight">Today's Focus</h2>
            <Link href="/train" className="text-primary font-bold text-sm hover:underline flex items-center">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          
          <Card className="overflow-hidden border-2 border-primary/20 hover:border-primary transition-colors cursor-pointer group shadow-sm">
            <div className="h-48 bg-gradient-to-br from-slate-900 via-primary/80 to-primary relative flex items-center justify-center">
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
              <PlaySquare className="w-16 h-16 text-white/90 group-hover:scale-110 transition-transform drop-shadow-md" />
              <div className="absolute bottom-4 left-4">
                <Badge variant="rep" className="mb-2 bg-secondary text-secondary-foreground shadow-sm">Recommended</Badge>
              </div>
            </div>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold">{dash.coachRecommendation.title}</h3>
                  <p className="text-muted-foreground font-medium mt-1">{dash.coachRecommendation.body}</p>
                </div>
                <Button size="sm" asChild className="ml-4 shrink-0 shadow-sm">
                  <Link href="/train">{dash.coachRecommendation.cta}</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <h2 className="text-2xl font-black uppercase tracking-tight flex items-center gap-2">
            <Calendar className="w-6 h-6 text-primary" /> Schedule
          </h2>
          <Card className="shadow-sm">
            <CardContent className="p-0 divide-y">
              {dash.schedule.map((event) => (
                <div key={event.id} className="p-4 flex gap-4 items-center hover:bg-muted/50 transition-colors">
                  <div className="w-16 text-center font-mono font-bold text-muted-foreground text-sm shrink-0">
                    {event.time}
                  </div>
                  <div className="w-1 h-10 rounded-full" style={{ backgroundColor: event.accent || 'var(--primary)' }} />
                  <div>
                    <div className="font-bold text-foreground">{event.title}</div>
                    <div className="text-xs font-bold text-muted-foreground uppercase">{event.kind}</div>
                  </div>
                </div>
              ))}
              {dash.schedule.length === 0 && (
                <div className="p-6 text-center text-muted-foreground font-bold">No events today.</div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
