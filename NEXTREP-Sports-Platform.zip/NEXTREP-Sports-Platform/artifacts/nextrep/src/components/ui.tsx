import * as React from "react";
import { cn } from "@/lib/utils";
import { Link } from "wouter";
import { Slot } from "@radix-ui/react-slot";

// BUTTON
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "secondary" | "outline" | "ghost" | "ghost-sport" | "destructive";
  size?: "sm" | "default" | "lg" | "icon";
  asChild?: boolean;
}
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", asChild = false, ...props }, ref) => {
    const variants = {
      default: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-sm",
      outline: "border-2 border-primary text-primary hover:bg-primary/10 font-semibold",
      ghost: "hover:bg-muted text-foreground",
      "ghost-sport": "hover:bg-primary/10 text-primary font-semibold hover:scale-[1.02] transition-transform",
      destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
    };
    const sizes = {
      default: "h-11 px-5 py-2",
      sm: "h-9 px-3 text-sm",
      lg: "h-14 px-8 text-lg font-bold uppercase tracking-wider",
      icon: "h-11 w-11 flex-shrink-0",
    };
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center rounded-md font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

// CARD
export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("rounded-xl border bg-card text-card-foreground shadow-sm", className)} {...props} />;
}
export function CardHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />;
}
export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h3 className={cn("text-xl font-bold leading-none tracking-tight", className)} {...props} />;
}
export function CardContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-6 pt-0", className)} {...props} />;
}

// BADGE
export function Badge({ className, variant = "default", ...props }: React.HTMLAttributes<HTMLDivElement> & { variant?: "default" | "secondary" | "outline" | "rep" }) {
  const variants = {
    default: "border-transparent bg-primary text-primary-foreground",
    secondary: "border-transparent bg-muted text-muted-foreground",
    outline: "text-foreground border-border",
    rep: "border-transparent bg-secondary text-secondary-foreground uppercase font-bold tracking-widest",
  };
  return (
    <div className={cn("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors", variants[variant], className)} {...props} />
  );
}

// AVATAR
export function Avatar({ className, src, alt, fallback }: { className?: string; src?: string; alt?: string; fallback?: string }) {
  return (
    <div className={cn("relative flex h-12 w-12 shrink-0 overflow-hidden rounded-full bg-muted", className)}>
      {src ? (
        <img src={src} alt={alt || ""} className="aspect-square h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center font-bold text-muted-foreground font-mono">
          {fallback || "NR"}
        </div>
      )}
    </div>
  );
}

// PROGRESS
export function Progress({ className, value, colorClass = "bg-primary" }: { className?: string; value: number; colorClass?: string }) {
  return (
    <div className={cn("relative h-3 w-full overflow-hidden rounded-full bg-muted", className)}>
      <div className={cn("h-full w-full flex-1 transition-all duration-500", colorClass)} style={{ transform: `translateX(-${100 - (value || 0)}%)` }} />
    </div>
  );
}

// SKELETON
export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("animate-pulse rounded-md bg-muted", className)} {...props} />;
}

// INPUT
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-11 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);
Input.displayName = "Input";

// TABS (Simple Implementation)
interface TabsContextType {
  activeTab: string;
  setActiveTab: (val: string) => void;
}
const TabsContext = React.createContext<TabsContextType | null>(null);

export function Tabs({ defaultValue, className, children, onValueChange }: { defaultValue: string; className?: string; children: React.ReactNode; onValueChange?: (v: string) => void }) {
  const [activeTab, setTab] = React.useState(defaultValue);
  const setActiveTab = (val: string) => {
    setTab(val);
    if (onValueChange) onValueChange(val);
  };
  return <TabsContext.Provider value={{ activeTab, setActiveTab }}><div className={className}>{children}</div></TabsContext.Provider>;
}

export function TabsList({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={cn("inline-flex h-12 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className)}>{children}</div>;
}

export function TabsTrigger({ value, className, children }: { value: string; className?: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext);
  const isActive = ctx?.activeTab === value;
  return (
    <button
      type="button"
      onClick={() => ctx?.setActiveTab(value)}
      className={cn(
        "inline-flex items-center justify-center whitespace-nowrap rounded-md px-4 py-2 text-sm font-bold transition-all disabled:pointer-events-none disabled:opacity-50",
        isActive ? "bg-background text-foreground shadow-sm" : "hover:bg-muted/80 hover:text-foreground",
        className
      )}
    >
      {children}
    </button>
  );
}

export function TabsContent({ value, className, children }: { value: string; className?: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext);
  if (ctx?.activeTab !== value) return null;
  return <div className={cn("mt-4 animate-fade-in", className)}>{children}</div>;
}
