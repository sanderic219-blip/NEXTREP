import React from "react";
import { useGetMindset, useSetMindsetFavorite, useListMindsetFavorites } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetMindsetQueryKey } from "@workspace/api-client-react";
import { Heart, Quote } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

export function DailyMindset() {
  const { data: mindset, isLoading } = useGetMindset({
    query: {
      queryKey: getGetMindsetQueryKey(),
      refetchInterval: 1000 * 60 * 60, // Refresh every hour to catch day rollover
      refetchOnWindowFocus: true,
    }
  });
  const setFavorite = useSetMindsetFavorite();
  const queryClient = useQueryClient();

  if (isLoading) {
    return (
      <Card className="border-l-4 border-l-primary">
        <CardContent className="p-4 space-y-3">
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-10 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!mindset) return null;

  const toggleFavorite = () => {
    setFavorite.mutate(
      { quoteId: mindset.id, data: { favorited: !mindset.favorited } },
      {
        onSuccess: (updated) => {
          queryClient.setQueryData(getGetMindsetQueryKey(), updated);
          queryClient.invalidateQueries({ queryKey: ["/api/mindset/favorites"] }); // Or use exact key if available
        }
      }
    );
  };

  return (
    <Card className="border-0 bg-transparent overflow-hidden relative shadow-lg group">
      <div className="absolute inset-0 bg-[url('/wallpapers/football.jpg')] bg-cover bg-center transition-transform duration-700 group-hover:scale-105" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-black/30" />
      
      <CardContent className="p-4 md:p-5 relative z-10 flex flex-col h-full min-h-[160px] justify-between">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-white/70 drop-shadow-sm">Daily Mindset</h3>
          <div className="flex gap-1 bg-black/40 backdrop-blur-sm rounded-full p-1 border border-white/10">
            <FavoritesDialog />
            <Button 
              variant="ghost" 
              size="icon" 
              className={`h-7 w-7 rounded-full transition-colors ${mindset.favorited ? "text-red-500 hover:text-red-400" : "text-white/70 hover:text-white"}`}
              onClick={toggleFavorite}
              disabled={setFavorite.isPending}
              aria-pressed={mindset.favorited}
            >
              <Heart className={`w-4 h-4 ${mindset.favorited ? "fill-current text-red-500" : ""}`} />
            </Button>
          </div>
        </div>
        <p className="font-bold text-sm md:text-base leading-snug text-white drop-shadow-md">
          "{mindset.text}"
        </p>
      </CardContent>
    </Card>
  );
}

function FavoritesDialog() {
  const { data: favorites = [], isLoading } = useListMindsetFavorites();
  const setFavorite = useSetMindsetFavorite();
  const queryClient = useQueryClient();

  const toggleFavorite = (id: string, currentlyFavorited: boolean) => {
    setFavorite.mutate(
      { quoteId: id, data: { favorited: !currentlyFavorited } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/mindset/favorites"] });
          queryClient.invalidateQueries({ queryKey: getGetMindsetQueryKey() });
        }
      }
    );
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-7 w-7 rounded-full text-white/70 hover:text-white">
          <Quote className="w-3.5 h-3.5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500 fill-current" />
            Saved Quotes
          </DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[400px] pr-4 mt-2">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : favorites.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground font-medium">
              No saved quotes yet. Favorite the daily mindset to build your collection.
            </div>
          ) : (
            <div className="space-y-4">
              {favorites.map(quote => (
                <div key={quote.id} className="p-4 bg-muted/50 rounded-lg relative group">
                  <Quote className="absolute top-2 left-2 w-6 h-6 text-primary/10" />
                  <p className="font-bold text-sm leading-snug italic relative z-10 pr-6">
                    "{quote.text}"
                  </p>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute top-2 right-2 h-6 w-6 text-red-500 hover:text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => toggleFavorite(quote.id, true)}
                  >
                    <Heart className="w-4 h-4 fill-current" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
