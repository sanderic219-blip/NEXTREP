import React, { useState, useEffect, useRef } from "react";
import { useGetPersonalization, useUpdatePersonalization, useUploadPersonalizationImage, getGetPersonalizationQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Upload, Paintbrush, Settings2 } from "lucide-react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { resolveAccentToHex, applyThemeHex } from "@/lib/utils";

const WALLPAPERS = [
  { id: "football", label: "Football" },
  { id: "basketball", label: "Basketball" },
  { id: "soccer", label: "Soccer" },
  { id: "gym", label: "Gym" },
  { id: "stadium", label: "Stadium" },
  { id: "nextrep-blue", label: "Nextrep Blue" },
  { id: "nextrep-orange", label: "Midnight" }
];

const ACCENTS = [
  { id: "blue", label: "Blue", class: "bg-blue-600" },
  { id: "#89CFF0", label: "Baby Blue", class: "bg-sky-200" },
  { id: "cyan", label: "Cyan", class: "bg-cyan-500" },
  { id: "purple", label: "Purple", class: "bg-purple-600" },
];

export function CustomizationDialog({ children }: { children: React.ReactNode }) {
  const { data: personalization } = useGetPersonalization();
  const updateMutation = useUpdatePersonalization();
  const uploadMutation = useUploadPersonalizationImage();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);

  const [wallpaper, setWallpaper] = useState<string>("football");
  const [accent, setAccent] = useState<string>("#89CFF0");
  const [avatarUrl, setAvatarUrl] = useState<string>("");
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // Initialize state when opening
  useEffect(() => {
    if (open && personalization) {
      setWallpaper(personalization.wallpaper || "football");
      setAccent(resolveAccentToHex(personalization.accent as string));
      setAvatarUrl(personalization.avatarUrl || "");
    }
  }, [open, personalization]);

  const handleSave = () => {
    updateMutation.mutate(
      { data: { wallpaper, accent: accent as any, avatarUrl } },
      {
        onSuccess: (data) => {
          queryClient.setQueryData(getGetPersonalizationQueryKey(), data);
          applyThemeHex(accent);
          toast({ title: "Customization saved", description: "Your theme has been updated." });
          setOpen(false);
        },
        onError: () => {
          toast({ title: "Error", description: "Failed to save customization.", variant: "destructive" });
        }
      }
    );
  };

  const handleFileUpload = (kind: "wallpaper"|"avatar", file: File) => {
    uploadMutation.mutate(
      { data: { kind, file } },
      {
        onSuccess: (data) => {
          if (kind === "wallpaper") setWallpaper(data.url);
          else setAvatarUrl(data.url);
          toast({ title: "Upload complete", description: "Image uploaded successfully." });
        },
        onError: () => {
          toast({ title: "Upload failed", description: "Could not upload the image.", variant: "destructive" });
        }
      }
    );
  };

  const isUploading = uploadMutation.isPending;
  const isSaving = updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] h-[85vh] sm:h-auto overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-primary" />
            Customize Experience
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-8 py-4">
          {/* Avatar Section */}
          <div className="space-y-3">
            <Label className="uppercase tracking-wider text-xs font-bold text-muted-foreground">Profile Avatar</Label>
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={avatarUrl} />
                <AvatarFallback>NR</AvatarFallback>
              </Avatar>
              <div className="flex flex-col gap-2">
                <Button variant="outline" size="sm" onClick={() => avatarInputRef.current?.click()} disabled={isUploading}>
                  {isUploading ? "Uploading..." : "Upload New"}
                </Button>
                {avatarUrl && (
                  <Button variant="ghost" size="sm" onClick={() => setAvatarUrl("")} className="text-destructive">
                    Remove
                  </Button>
                )}
                <input 
                  type="file" 
                  ref={avatarInputRef} 
                  className="hidden" 
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload("avatar", file);
                  }}
                />
              </div>
            </div>
          </div>

          {/* Accent Color Section */}
          <div className="space-y-3">
            <Label className="uppercase tracking-wider text-xs font-bold text-muted-foreground">Theme Color</Label>
            <div className="flex gap-4 items-center">
              <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-border shadow-sm shrink-0 cursor-pointer hover:scale-105 transition-transform">
                <input 
                  type="color" 
                  value={accent} 
                  onChange={(e) => setAccent(e.target.value)} 
                  className="absolute -inset-4 w-20 h-20 cursor-pointer"
                />
              </div>
              <div className="flex-1 max-w-[160px]">
                <Input 
                  value={accent} 
                  onChange={(e) => setAccent(e.target.value)} 
                  placeholder="#RRGGBB" 
                  className="font-mono uppercase bg-background" 
                  maxLength={7}
                />
              </div>
            </div>
          </div>

          {/* Wallpaper Section */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <Label className="uppercase tracking-wider text-xs font-bold text-muted-foreground">Dashboard Wallpaper</Label>
              <Button variant="ghost" size="sm" onClick={() => fileInputRef.current?.click()} disabled={isUploading} className="h-8">
                <Upload className="w-4 h-4 mr-2" /> Upload Custom
              </Button>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/jpeg,image/png,image/webp"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileUpload("wallpaper", file);
                }}
              />
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {WALLPAPERS.map((wp) => (
                <div 
                  key={wp.id}
                  onClick={() => setWallpaper(wp.id)}
                  className={`relative aspect-video rounded-md overflow-hidden cursor-pointer border-2 transition-all ${wallpaper === wp.id ? 'border-primary shadow-md' : 'border-transparent opacity-70 hover:opacity-100'}`}
                >
                  <img src={`${import.meta.env.BASE_URL}wallpapers/${wp.id}.${wp.id.startsWith("nextrep-") ? "svg" : "jpg"}`} alt={wp.label} className="w-full h-full object-cover" />
                  {wallpaper === wp.id && (
                    <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                      <div className="bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded-full uppercase">Active</div>
                    </div>
                  )}
                </div>
              ))}
              {(wallpaper.startsWith('/api/') || wallpaper.startsWith('http')) && (
                <div 
                  onClick={() => {}}
                  className={`relative aspect-video rounded-md overflow-hidden border-2 border-primary shadow-md`}
                >
                  <img src={wallpaper} alt="Custom" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                    <div className="bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded-full uppercase">Custom Active</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)} disabled={isSaving}>Cancel</Button>
          <Button onClick={handleSave} disabled={isSaving || isUploading}>
            {isSaving ? "Saving..." : "Save Customization"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
