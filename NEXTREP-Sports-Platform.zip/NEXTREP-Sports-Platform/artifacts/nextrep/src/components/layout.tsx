import React from "react";
import { Link, useLocation } from "wouter";
import { useClerk } from "@clerk/react";
import { useGetPersonalization, useGetDashboard } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Activity, 
  Home, 
  PlaySquare, 
  MessageSquare, 
  Trophy, 
  UserCircle,
  Share2,
  LogOut
} from "lucide-react";
import { DailyMindset } from "@/components/mindset/DailyMindset";
import { cn, resolveAccentToHex, applyThemeHex } from "@/lib/utils";
import { useEffect } from "react";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dash", icon: Home },
  { href: "/train", label: "Train", icon: PlaySquare },
  { href: "/progress", label: "Progress", icon: Activity },
  { href: "/coach", label: "Coach", icon: MessageSquare },
  { href: "/challenges", label: "Compete", icon: Trophy },
  { href: "/profile", label: "Profile", icon: UserCircle },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  
  const { data: personalization } = useGetPersonalization();
  const { data: dash } = useGetDashboard();

  const avatarUrl = personalization?.avatarUrl || dash?.athlete?.avatarUrl;
  const initials = dash?.athlete ? `${dash.athlete.firstName.charAt(0)}` : "NR";

  useEffect(() => {
    if (personalization) {
      applyThemeHex(resolveAccentToHex(personalization.accent as string));
    } else {
      applyThemeHex("#89CFF0");
    }
  }, [personalization]);

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background">
      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between p-4 bg-card border-b sticky top-0 z-50">
        <div className="font-black text-xl tracking-tighter text-primary">NEXTREP</div>
        <div className="flex items-center gap-4">
          <Avatar className="h-8 w-8 ring-2 ring-primary/20">
            <AvatarImage src={avatarUrl} />
            <AvatarFallback className="text-xs font-black">{initials}</AvatarFallback>
          </Avatar>
          <button onClick={() => signOut({ redirectUrl: import.meta.env.BASE_URL.replace(/\/$/, "") || "/" })} className="text-muted-foreground hover:text-destructive">
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex w-64 flex-col bg-card border-r sticky top-0 h-screen shrink-0 z-10">
        <div className="p-6 pb-2">
          <div className="font-black text-3xl tracking-tighter text-primary flex items-center gap-2">
            <Activity className="w-8 h-8 text-secondary" />
            NEXTREP
          </div>
          <p className="text-xs font-bold text-muted-foreground mt-1 uppercase tracking-widest">Athlete Portal</p>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-lg font-bold text-base transition-all cursor-pointer",
                    isActive 
                      ? "bg-primary text-primary-foreground shadow-sm" 
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  )}
                >
                  {item.href === "/profile" ? (
                    <Avatar className={cn("w-5 h-5", isActive ? "ring-2 ring-primary-foreground" : "ring-1 ring-muted-foreground/30")}>
                      <AvatarImage src={avatarUrl} />
                      <AvatarFallback className="text-[10px] font-black">{initials}</AvatarFallback>
                    </Avatar>
                  ) : (
                    <Icon className={cn("w-5 h-5", isActive ? "text-primary-foreground" : "text-muted-foreground")} />
                  )}
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>
        
        <div className="p-4 border-t space-y-4">
          <div className="hidden md:block">
            <DailyMindset />
          </div>
          <div className="space-y-2">
            <Link href="/recruit">
              <div className="flex w-full items-center justify-center gap-2 px-4 py-3 rounded-lg font-bold text-sm bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-colors shadow-sm cursor-pointer uppercase tracking-wider">
                <Share2 className="w-4 h-4" />
                Recruiting Profile
              </div>
            </Link>
            <button 
              onClick={() => signOut({ redirectUrl: import.meta.env.BASE_URL.replace(/\/$/, "") || "/" })}
              className="flex w-full items-center justify-center gap-2 px-4 py-3 rounded-lg font-bold text-sm text-muted-foreground hover:bg-muted transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              Log Out
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 pb-20 md:pb-0 overflow-x-hidden">
        <div className="max-w-5xl mx-auto p-4 md:p-8 animate-fade-in">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t flex items-center justify-around p-2 pb-safe z-50">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <div className="flex flex-col items-center justify-center w-14 h-12 cursor-pointer relative">
                {isActive && (
                  <div className="absolute -top-3 w-8 h-1 bg-primary rounded-b-full" />
                )}
                {item.href === "/profile" ? (
                  <Avatar className={cn("w-5 h-5 mb-1", isActive ? "ring-2 ring-primary ring-offset-1 ring-offset-card" : "")}>
                    <AvatarImage src={avatarUrl} />
                    <AvatarFallback className="text-[8px] font-black">{initials}</AvatarFallback>
                  </Avatar>
                ) : (
                  <Icon className={cn("w-5 h-5 mb-1", isActive ? "text-primary" : "text-muted-foreground")} />
                )}
                <span className={cn("text-[10px] font-bold", isActive ? "text-primary" : "text-muted-foreground")}>
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
