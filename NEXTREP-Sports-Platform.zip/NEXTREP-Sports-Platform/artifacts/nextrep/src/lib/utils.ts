import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateString: string) {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

export function formatDuration(durationStr: string) {
  return durationStr;
}

export function hexToHsl(hex: string) {
  hex = hex.replace(/^#/, '');
  if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
  
  const r = parseInt(hex.substring(0, 2), 16) / 255 || 0;
  const g = parseInt(hex.substring(2, 4), 16) / 255 || 0;
  const b = parseInt(hex.substring(4, 6), 16) / 255 || 0;

  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export function resolveAccentToHex(accent?: string | null): string {
  if (!accent) return "#89CFF0"; // Default baby blue
  const presets: Record<string, string> = {
    blue: "#3b82f6",
    orange: "#89CFF0", // Compatibility override -> baby blue
    cyan: "#06b6d4",
    purple: "#a855f7"
  };
  return presets[accent.toLowerCase()] || (accent.startsWith("#") ? accent : "#89CFF0");
}

export function getLuminance(r: number, g: number, b: number) {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

export function applyThemeHex(hex: string) {
  if (typeof document === "undefined") return;
  const validHex = hex.match(/^#[0-9A-Fa-f]{6}$/i) ? hex : "#89CFF0";
  const hsl = hexToHsl(validHex);
  
  document.documentElement.style.setProperty("--primary", hsl);
  document.documentElement.style.setProperty("--ring", hsl);
  
  const r = parseInt(validHex.slice(1, 3), 16);
  const g = parseInt(validHex.slice(3, 5), 16);
  const b = parseInt(validHex.slice(5, 7), 16);
  const luminance = getLuminance(r, g, b);
  
  const contrastWithWhite = 1.05 / (luminance + 0.05);
  const contrastWithBlack = (luminance + 0.05) / 0.05;
  
  document.documentElement.style.setProperty(
    "--primary-foreground", 
    contrastWithBlack > contrastWithWhite ? "222 47% 6%" : "0 0% 100%"
  );
}
