import { getAuth } from "@clerk/express";
import type { NextFunction, Request, Response } from "express";

export type AuthenticatedRequest = Request & {
  userId: string;
};

export function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const auth = getAuth(req);
  const sessionClaims = auth as unknown as {
    userId?: string;
    sessionClaims?: { userId?: string };
  };
  const userId = sessionClaims.userId ?? sessionClaims.sessionClaims?.userId;

  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  (req as AuthenticatedRequest).userId = userId;
  next();
}

export function getAuthenticatedUserId(req: Request): string {
  const userId = (req as Partial<AuthenticatedRequest>).userId;
  if (!userId) {
    throw new Error("Authenticated user is missing");
  }
  return userId;
}