import { Router, type IRouter } from "express";
import healthRouter from "./health";
import nextrepRouter from "./nextrep";

const router: IRouter = Router();

router.use(healthRouter);
router.use(nextrepRouter);

export default router;
