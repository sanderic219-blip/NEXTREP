import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import {
  Router,
  type IRouter,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import multer from "multer";
import { and, asc, eq, ne, sql } from "drizzle-orm";
import {
  AddTrainingVideoToWorkoutBody,
  AddTrainingVideoToWorkoutParams,
  AddTrainingVideoToWorkoutResponse,
  CompleteWorkoutParams,
  CompleteWorkoutResponse,
  GetAthleteProfileResponse,
  GetAthleteProgressResponse,
  GetCoachRecommendationResponse,
  GetDashboardResponse,
  GetMindsetResponse,
  GetPersonalizationImageParams,
  GetPersonalizationResponse,
  ListChallengesResponse,
  ListLeaderboardResponse,
  ListMindsetFavoritesResponse,
  ListTrainingVideosQueryParams,
  ListTrainingVideosResponse,
  SendCoachMessageBody,
  SendCoachMessageResponse,
  SetMindsetFavoriteBody,
  SetMindsetFavoriteParams,
  SetMindsetFavoriteResponse,
  ToggleTrainingVideoLikeParams,
  ToggleTrainingVideoLikeResponse,
  ToggleTrainingVideoSaveParams,
  ToggleTrainingVideoSaveResponse,
  UpdateAthleteProfileBody,
  UpdateAthleteProfileResponse,
  UpdatePersonalizationBody,
  UpdatePersonalizationResponse,
  UploadPersonalizationImageBody,
  UploadPersonalizationImageResponse,
} from "@workspace/api-zod";
import {
  athleteVideoReactionsTable,
  athletesTable,
  coachMessagesTable,
  db,
  mindsetFavoritesTable,
  personalizationImagesTable,
  trainingVideosTable,
  workoutItemsTable,
  type Athlete,
  type TrainingVideo,
} from "@workspace/db";
import { requireAuth, getAuthenticatedUserId } from "../middlewares/requireAuth";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
router.use(requireAuth);

const objectStorageService = new ObjectStorageService();
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const DEFAULT_ACCENT = "#89CFF0";
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_IMAGE_BYTES },
});

const wallpaperKeys = new Set([
  "football",
  "basketball",
  "soccer",
  "gym",
  "stadium",
  "nextrep-blue",
  "nextrep-orange",
]);
const accentKeys = new Set(["blue", "orange", "cyan", "purple"]);

function isValidAccent(value: string): boolean {
  return accentKeys.has(value) || /^#[0-9A-Fa-f]{6}$/.test(value);
}

const mindsetQuotes = [
  { id: "quote-01", text: "Do the work with humility, then let the work speak." },
  { id: "quote-02", text: "Discipline is choosing the next right rep when nobody is watching." },
  { id: "quote-03", text: "A teammate's progress is part of your progress." },
  { id: "quote-04", text: "Small improvements become a different athlete over time." },
  { id: "quote-05", text: "Stay teachable; every rep has something to show you." },
  { id: "quote-06", text: "Consistency is a quiet promise kept one day at a time." },
  { id: "quote-07", text: "Bring energy to the team before asking the team for energy." },
  { id: "quote-08", text: "Compete with yesterday, not with someone else's chapter." },
  { id: "quote-09", text: "The standard rises when you practice the basics with care." },
  { id: "quote-10", text: "A hard day is still useful when you meet it with purpose." },
  { id: "quote-11", text: "Listen closely, apply the lesson, and come back better." },
  { id: "quote-12", text: "Great teams make room for every person's best contribution." },
  { id: "quote-13", text: "Progress often looks ordinary while it is happening." },
  { id: "quote-14", text: "Work rate is a choice you can make before motivation arrives." },
  { id: "quote-15", text: "The best teammate is prepared, present, and generous." },
  { id: "quote-16", text: "Be proud of the effort, then stay hungry for the next lesson." },
  { id: "quote-17", text: "One clean rep teaches more than ten careless ones." },
  { id: "quote-18", text: "Your attitude is part of the equipment you bring to practice." },
  { id: "quote-19", text: "Make the group stronger by doing your part exceptionally well." },
  { id: "quote-20", text: "Improvement starts when excuses stop getting the final word." },
  { id: "quote-21", text: "Stay patient with the process and impatient with complacency." },
  { id: "quote-22", text: "The work counts even when the scoreboard is quiet." },
  { id: "quote-23", text: "Give credit freely; confidence grows in a team that shares it." },
  { id: "quote-24", text: "Your future level is built from today's repeatable habits." },
  { id: "quote-25", text: "Arrive ready to learn, not just ready to be seen." },
  { id: "quote-26", text: "Good preparation turns pressure into a familiar assignment." },
  { id: "quote-27", text: "Leave every session having improved one detail." },
  { id: "quote-28", text: "Lead with actions, receive feedback, and keep moving forward." },
  { id: "quote-29", text: "There is strength in doing the unglamorous work together." },
  { id: "quote-30", text: "Earn trust through dependable effort, especially on hard days." },
  { id: "quote-31", text: "Stay grounded in the basics while reaching for the next level." },
  { id: "quote-32", text: "The team remembers who made difficult work feel possible." },
  { id: "quote-33", text: "Focus on what you can control: preparation, effort, and response." },
  { id: "quote-34", text: "Better is available in the next decision, not just the next season." },
  { id: "quote-35", text: "Quiet confidence comes from promises you repeatedly keep to yourself." },
  { id: "quote-36", text: "Make today's work worthy of the teammate you want to become." },
];

const recommendation = {
  eyebrow: "Built for today",
  title: "Practice-day speed primer",
  body: "You have football practice later, so today's session keeps leg volume low and focuses on reaction speed, hip mobility, and clean footwork.",
  cta: "Open 18-minute plan",
};

function coachReply(message: string): string {
  const lower = message.toLowerCase();
  if (lower.includes("sore") || lower.includes("recovery")) {
    return "Keep today's intensity at about 60%. Start with eight minutes of hip and ankle mobility, then do three low-volume footwork sets. Skip heavy lower-body work and finish with an easy recovery walk.";
  }
  if (lower.includes("20 minute") || lower.includes("20-minute")) {
    return "Use a 20-minute defensive back session: four minutes of dynamic warmup, eight minutes of backpedal and break drills, five minutes of reaction starts, then three minutes of mobility.";
  }
  if (lower.includes("game tomorrow")) {
    return "Treat today as activation, not conditioning. Do a short dynamic warmup, crisp position footwork at low volume, and finish with mobility. You should leave feeling faster than when you started.";
  }
  if (lower.includes("dumbbell")) {
    return "Build the session around split squats, single-leg Romanian deadlifts, floor press, rows, and loaded carries. Keep the reps explosive and stop each set before your speed drops.";
  }
  return "Based on your schedule and recent work, focus on quality footwork and reaction speed today. I can turn that into a short session or a full workout—tell me how much time and equipment you have.";
}

async function athleteForUser(clerkUserId: string): Promise<Athlete> {
  const [existing] = await db
    .select()
    .from(athletesTable)
    .where(eq(athletesTable.clerkUserId, clerkUserId))
    .limit(1);
  if (existing) {
    return existing;
  }

  await db
    .insert(athletesTable)
    .values({
      clerkUserId,
      name: "NEXTREP Athlete",
      firstName: "Athlete",
      sport: "Football",
      position: "Athlete",
      graduationYear: new Date().getUTCFullYear() + 1,
      height: "",
      weight: "",
      school: "",
      location: "",
      gpa: 0,
      repScore: 0,
      xp: 0,
      level: 1,
      streak: 0,
      workoutsCompleted: 0,
      avatarUrl: "",
      wallpaper: "nextrep-blue",
      accent: DEFAULT_ACCENT,
    })
    .onConflictDoNothing({ target: athletesTable.clerkUserId });

  const [created] = await db
    .select()
    .from(athletesTable)
    .where(eq(athletesTable.clerkUserId, clerkUserId))
    .limit(1);
  if (!created) {
    throw new Error("Unable to provision athlete for Clerk user");
  }
  return created;
}

async function currentAthlete(req: Request): Promise<Athlete> {
  return athleteForUser(getAuthenticatedUserId(req));
}

function profileFor(athlete: Athlete) {
  return {
    id: athlete.id,
    name: athlete.name,
    sport: athlete.sport,
    position: athlete.position,
    graduationYear: athlete.graduationYear,
    height: athlete.height,
    weight: athlete.weight,
    school: athlete.school,
    location: athlete.location,
    gpa: athlete.gpa,
    repScore: athlete.repScore,
    avatarUrl: athlete.avatarUrl,
    stats: [
      { label: "40 Yard", value: "4.71" },
      { label: "Vertical", value: '31"' },
      { label: "Bench", value: "185 lb" },
    ],
    achievements: [
      {
        title: "12-Day Streak",
        description: "Consistent work compounds",
        icon: "flame",
      },
      {
        title: "Personal Best",
        description: "New 40-yard benchmark",
        icon: "trending-up",
        },
      {
        title: "Top Performer",
        description: "Top 10% at your position",
        icon: "award",
      },
    ],
  };
}

async function favoriteQuoteIds(athleteId: number): Promise<string[]> {
  const rows = await db
    .select({ quoteId: mindsetFavoritesTable.quoteId })
    .from(mindsetFavoritesTable)
    .where(eq(mindsetFavoritesTable.athleteId, athleteId));
  const ids = new Set(rows.map((row) => row.quoteId));
  return mindsetQuotes
    .filter((quote) => ids.has(quote.id))
    .map((quote) => quote.id);
}

function personalizationImageId(value: string): string | null {
  const match = /^\/(?:api\/)?personalization\/images\/([0-9a-f-]{36})$/.exec(
    value,
  );
  return match?.[1] ?? null;
}

async function ownedImage(
  athleteId: number,
  value: string,
  kind: "wallpaper" | "avatar",
): Promise<boolean> {
  const id = personalizationImageId(value);
  if (!id) {
    return false;
  }
  const [image] = await db
    .select({ id: personalizationImagesTable.id })
    .from(personalizationImagesTable)
    .where(
      and(
        eq(personalizationImagesTable.id, id),
        eq(personalizationImagesTable.athleteId, athleteId),
        eq(personalizationImagesTable.kind, kind),
      ),
    )
    .limit(1);
  return Boolean(image);
}

async function personalizationFor(athlete: Athlete) {
  return {
    wallpaper: athlete.wallpaper,
    accent: athlete.accent || DEFAULT_ACCENT,
    avatarUrl: athlete.avatarUrl,
    favoriteQuotes: await favoriteQuoteIds(athlete.id),
  };
}

function dailyMindsetQuote() {
  const now = new Date();
  const dayNumber = Math.floor(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()) /
      86_400_000,
  );
  return mindsetQuotes[dayNumber % mindsetQuotes.length];
}

async function quoteWithFavorite(athleteId: number, quoteId: string) {
  const quote = mindsetQuotes.find((item) => item.id === quoteId);
  if (!quote) {
    return undefined;
  }
  const [favorite] = await db
    .select({ id: mindsetFavoritesTable.id })
    .from(mindsetFavoritesTable)
    .where(
      and(
        eq(mindsetFavoritesTable.athleteId, athleteId),
        eq(mindsetFavoritesTable.quoteId, quoteId),
      ),
    )
    .limit(1);
  return { ...quote, favorited: Boolean(favorite) };
}

function trainingVideoFor(
  video: TrainingVideo,
  reaction: { liked: boolean; saved: boolean } | undefined,
) {
  return {
    id: video.id,
    coach: video.coach,
    coachInitials: video.coachInitials,
    verified: video.verified,
    drillName: video.drillName,
    sport: video.sport,
    position: video.position,
    difficulty: video.difficulty,
    duration: video.duration,
    likes: video.likes,
    comments: video.comments,
    saves: video.saves,
    shares: video.shares,
    liked: reaction?.liked ?? false,
    saved: reaction?.saved ?? false,
    thumbnailUrl: video.thumbnailUrl,
    gradient: video.gradient,
  };
}

function detectImageContentType(buffer: Buffer): string | null {
  if (
    buffer.length >= 3 &&
    buffer[0] === 0xff &&
    buffer[1] === 0xd8 &&
    buffer[2] === 0xff
  ) {
    return "image/jpeg";
  }
  if (
    buffer.length >= 8 &&
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).equals(
      buffer.subarray(0, 8),
    )
  ) {
    return "image/png";
  }
  if (
    buffer.length >= 12 &&
    buffer.subarray(0, 4).toString("ascii") === "RIFF" &&
    buffer.subarray(8, 12).toString("ascii") === "WEBP"
  ) {
    return "image/webp";
  }
  return null;
}

function uploadImageMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  upload.single("file")(req, res, (error: unknown) => {
    if (!error) {
      next();
      return;
    }
    if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
      res.status(413).json({ error: "Image must be 5MB or smaller" });
      return;
    }
    res.status(400).json({ error: "Invalid image upload" });
  });
}

router.get("/dashboard", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  res.json(
    GetDashboardResponse.parse({
      athlete: {
        name: athlete.name,
        firstName: athlete.firstName,
        sport: athlete.sport,
        position: athlete.position,
        avatarUrl: athlete.avatarUrl,
      },
      stats: {
        repScore: athlete.repScore,
        xp: athlete.xp,
        level: athlete.level,
        streak: athlete.streak,
        workoutsCompleted: athlete.workoutsCompleted,
      },
      schedule: [
        { id: 1, title: "Football practice", time: "4:00 PM", kind: "practice", accent: "lime" },
        { id: 2, title: "Speed training", time: "6:30 PM", kind: "workout", accent: "orange" },
        { id: 3, title: "Recovery", time: "7:30 PM", kind: "recovery", accent: "blue" },
      ],
      weeklyGoal: {
        completed: Math.min(4, athlete.workoutsCompleted),
        target: 4,
        label: "Workouts completed",
      },
      coachRecommendation: recommendation,
    }),
  );
});

router.get("/train/feed", async (req, res): Promise<void> => {
  const query = ListTrainingVideosQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const [rows, reactions] = await Promise.all([
    db.select().from(trainingVideosTable).orderBy(asc(trainingVideosTable.id)),
    db
      .select({
        videoId: athleteVideoReactionsTable.videoId,
        liked: athleteVideoReactionsTable.liked,
        saved: athleteVideoReactionsTable.saved,
      })
      .from(athleteVideoReactionsTable)
      .where(eq(athleteVideoReactionsTable.athleteId, athlete.id)),
  ]);
  const reactionMap = new Map(reactions.map((reaction) => [reaction.videoId, reaction]));
  const category = query.data.category?.toLowerCase();
  const videos = rows
    .filter(
      (video) =>
        !category ||
        ["for you", "following", "more"].includes(category) ||
        video.sport.toLowerCase() === category,
    )
    .map((video) => trainingVideoFor(video, reactionMap.get(video.id)));
  res.json(ListTrainingVideosResponse.parse(videos));
});

router.post("/train/videos/:videoId/like", async (req, res): Promise<void> => {
  const params = ToggleTrainingVideoLikeParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const [video] = await db
    .select()
    .from(trainingVideosTable)
    .where(eq(trainingVideosTable.id, params.data.videoId));
  if (!video) {
    res.status(404).json({ error: "Training video not found" });
    return;
  }
  await db.transaction(async (tx) => {
    const [reaction] = await tx
      .select()
      .from(athleteVideoReactionsTable)
      .where(
        and(
          eq(athleteVideoReactionsTable.athleteId, athlete.id),
          eq(athleteVideoReactionsTable.videoId, video.id),
        ),
      )
      .limit(1);
    const liked = !(reaction?.liked ?? false);
    if (reaction) {
      await tx
        .update(athleteVideoReactionsTable)
        .set({ liked })
        .where(eq(athleteVideoReactionsTable.id, reaction.id));
    } else {
      await tx.insert(athleteVideoReactionsTable).values({
        athleteId: athlete.id,
        videoId: video.id,
        liked: true,
        saved: false,
      });
    }
    const delta = liked ? 1 : -1;
    await tx
      .update(trainingVideosTable)
      .set({ likes: sql`GREATEST(0, ${trainingVideosTable.likes} + ${delta})` })
      .where(eq(trainingVideosTable.id, video.id));
  });
  const [updatedVideo] = await db
    .select()
    .from(trainingVideosTable)
    .where(eq(trainingVideosTable.id, video.id));
  const [reaction] = await db
    .select({
      liked: athleteVideoReactionsTable.liked,
      saved: athleteVideoReactionsTable.saved,
    })
    .from(athleteVideoReactionsTable)
    .where(
      and(
        eq(athleteVideoReactionsTable.athleteId, athlete.id),
        eq(athleteVideoReactionsTable.videoId, video.id),
      ),
    )
    .limit(1);
  res.json(
    ToggleTrainingVideoLikeResponse.parse(
      trainingVideoFor(updatedVideo, reaction),
    ),
  );
});

router.post("/train/videos/:videoId/save", async (req, res): Promise<void> => {
  const params = ToggleTrainingVideoSaveParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const [video] = await db
    .select()
    .from(trainingVideosTable)
    .where(eq(trainingVideosTable.id, params.data.videoId));
  if (!video) {
    res.status(404).json({ error: "Training video not found" });
    return;
  }
  await db.transaction(async (tx) => {
    const [reaction] = await tx
      .select()
      .from(athleteVideoReactionsTable)
      .where(
        and(
          eq(athleteVideoReactionsTable.athleteId, athlete.id),
          eq(athleteVideoReactionsTable.videoId, video.id),
        ),
      )
      .limit(1);
    const saved = !(reaction?.saved ?? false);
    if (reaction) {
      await tx
        .update(athleteVideoReactionsTable)
        .set({ saved })
        .where(eq(athleteVideoReactionsTable.id, reaction.id));
    } else {
      await tx.insert(athleteVideoReactionsTable).values({
        athleteId: athlete.id,
        videoId: video.id,
        liked: false,
        saved: true,
      });
    }
    const delta = saved ? 1 : -1;
    await tx
      .update(trainingVideosTable)
      .set({ saves: sql`GREATEST(0, ${trainingVideosTable.saves} + ${delta})` })
      .where(eq(trainingVideosTable.id, video.id));
  });
  const [updatedVideo] = await db
    .select()
    .from(trainingVideosTable)
    .where(eq(trainingVideosTable.id, video.id));
  const [reaction] = await db
    .select({
      liked: athleteVideoReactionsTable.liked,
      saved: athleteVideoReactionsTable.saved,
    })
    .from(athleteVideoReactionsTable)
    .where(
      and(
        eq(athleteVideoReactionsTable.athleteId, athlete.id),
        eq(athleteVideoReactionsTable.videoId, video.id),
      ),
    )
    .limit(1);
  res.json(
    ToggleTrainingVideoSaveResponse.parse(
      trainingVideoFor(updatedVideo, reaction),
    ),
  );
});

router.post(
  "/train/videos/:videoId/workout",
  async (req, res): Promise<void> => {
    const params = AddTrainingVideoToWorkoutParams.safeParse(req.params);
    const body = AddTrainingVideoToWorkoutBody.safeParse(req.body ?? {});
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const athlete = await currentAthlete(req);
    const [video] = await db
      .select()
      .from(trainingVideosTable)
      .where(eq(trainingVideosTable.id, params.data.videoId));
    if (!video) {
      res.status(404).json({ error: "Training video not found" });
      return;
    }
    const [workout] = await db
      .insert(workoutItemsTable)
      .values({
        athleteId: athlete.id,
        videoId: video.id,
        title: video.drillName,
        duration: video.duration,
        status: "scheduled",
        scheduledDate: body.data.date ?? new Date().toISOString().slice(0, 10),
      })
      .returning();
    res.status(201).json(AddTrainingVideoToWorkoutResponse.parse(workout));
  },
);

router.post("/workouts/:workoutId/complete", async (req, res): Promise<void> => {
  const params = CompleteWorkoutParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const result = await db.transaction(async (tx) => {
    const [workout] = await tx
      .update(workoutItemsTable)
      .set({
        status: "completed",
        xpEarned: 150,
        completedAt: new Date(),
      })
      .where(
        and(
          eq(workoutItemsTable.id, params.data.workoutId),
          eq(workoutItemsTable.athleteId, athlete.id),
          ne(workoutItemsTable.status, "completed"),
        ),
      )
      .returning();

    if (!workout) {
      const [alreadyCompleted] = await tx
        .select()
        .from(workoutItemsTable)
        .where(
          and(
            eq(workoutItemsTable.id, params.data.workoutId),
            eq(workoutItemsTable.athleteId, athlete.id),
          ),
        )
        .limit(1);
      if (!alreadyCompleted) {
        return undefined;
      }
      const [current] = await tx
        .select({ repScore: athletesTable.repScore })
        .from(athletesTable)
        .where(eq(athletesTable.id, athlete.id))
        .limit(1);
      return {
        workout: alreadyCompleted,
        newRepScore:
          alreadyCompleted.completionRepScore ?? current?.repScore ?? 0,
      };
    }

    const [updatedAthlete] = await tx
      .update(athletesTable)
      .set({
        xp: sql`${athletesTable.xp} + 150`,
        repScore: sql`LEAST(100, ${athletesTable.repScore} + 1)`,
        workoutsCompleted: sql`${athletesTable.workoutsCompleted} + 1`,
      })
      .where(eq(athletesTable.id, athlete.id))
      .returning();
    if (!updatedAthlete) {
      throw new Error("Athlete disappeared while completing workout");
    }
    const [savedWorkout] = await tx
      .update(workoutItemsTable)
      .set({ completionRepScore: updatedAthlete.repScore })
      .where(eq(workoutItemsTable.id, workout.id))
      .returning();
    return {
      workout: savedWorkout ?? workout,
      newRepScore: updatedAthlete.repScore,
    };
  });

  if (!result) {
    res.status(404).json({ error: "Workout not found" });
    return;
  }
  res.json(
    CompleteWorkoutResponse.parse({
      workoutId: result.workout.id,
      xpEarned: result.workout.xpEarned,
      newRepScore: result.newRepScore,
      message: "Workout complete. Another rep toward your next level.",
    }),
  );
});

router.get("/coach/recommendation", (_req, res): void => {
  res.json(GetCoachRecommendationResponse.parse(recommendation));
});

router.post("/coach/chat", async (req, res): Promise<void> => {
  const body = SendCoachMessageBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  await db.insert(coachMessagesTable).values({
    athleteId: athlete.id,
    role: "athlete",
    message: body.data.message,
  });
  const [reply] = await db
    .insert(coachMessagesTable)
    .values({
      athleteId: athlete.id,
      role: "coach",
      message: coachReply(body.data.message),
    })
    .returning();
  res.json(
    SendCoachMessageResponse.parse({
      id: reply.id,
      role: reply.role,
      message: reply.message,
      createdAt: reply.createdAt.toISOString(),
    }),
  );
});

router.get("/athlete/profile", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  res.json(GetAthleteProfileResponse.parse(profileFor(athlete)));
});

router.patch("/athlete/profile", async (req, res): Promise<void> => {
  const body = UpdateAthleteProfileBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const [updated] = await db
    .update(athletesTable)
    .set(body.data)
    .where(eq(athletesTable.id, athlete.id))
    .returning();
  res.json(UpdateAthleteProfileResponse.parse(profileFor(updated)));
});

router.get("/athlete/progress", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  res.json(
    GetAthleteProgressResponse.parse({
      repScore: athlete.repScore,
      scoreChange: 6,
      weeklyActivity: [
        { day: "Mon", value: 62 },
        { day: "Tue", value: 78 },
        { day: "Wed", value: 45 },
        { day: "Thu", value: 86 },
        { day: "Fri", value: 71 },
        { day: "Sat", value: 93 },
        { day: "Sun", value: 54 },
      ],
      personalRecords: [
        { label: "40 Yard", value: "4.71", change: "-0.08 sec" },
        { label: "Vertical", value: '31"', change: '+2.5"' },
        { label: "Bench", value: "185 lb", change: "+15 lb" },
      ],
      recentWins: [
        "Completed four workouts this week",
        "Set a new 40-yard personal best",
        "Moved into the top 10% for defensive backs",
      ],
    }),
  );
});

router.get("/challenges", (_req, res): void => {
  res.json(
    ListChallengesResponse.parse([
      {
        id: 1,
        title: "Summer Grind",
        description: "Complete four focused workouts this week.",
        progress: 3,
        target: 4,
        reward: "500 XP",
        endsIn: "2 days",
      },
      {
        id: 2,
        title: "Seven-Day Mobility",
        description: "Finish a mobility session every day.",
        progress: 5,
        target: 7,
        reward: "Recovery badge",
        endsIn: "3 days",
      },
      {
        id: 3,
        title: "Speed Lab",
        description: "Log three verified speed sessions.",
        progress: 1,
        target: 3,
        reward: "350 XP",
        endsIn: "8 days",
      },
    ]),
  );
});

router.get("/leaderboard", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  res.json(
    ListLeaderboardResponse.parse([
      { rank: 1, name: "Marcus Reed", position: "WR", score: 94, change: 1, avatarUrl: "", isCurrentUser: false },
      { rank: 2, name: "Jaylen Brooks", position: "CB", score: 91, change: 0, avatarUrl: "", isCurrentUser: false },
      { rank: 3, name: "Avery Cole", position: "RB", score: 89, change: 2, avatarUrl: "", isCurrentUser: false },
      { rank: 4, name: athlete.name, position: athlete.position, score: athlete.repScore, change: 3, avatarUrl: athlete.avatarUrl, isCurrentUser: true },
      { rank: 5, name: "Noah Grant", position: "LB", score: 82, change: -1, avatarUrl: "", isCurrentUser: false },
    ]),
  );
});

router.get("/personalization", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  res.json(GetPersonalizationResponse.parse(await personalizationFor(athlete)));
});

router.patch("/personalization", async (req, res): Promise<void> => {
  const body = UpdatePersonalizationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const data = body.data;

  if (
    data.wallpaper !== undefined &&
    !wallpaperKeys.has(data.wallpaper) &&
    !(await ownedImage(athlete.id, data.wallpaper, "wallpaper"))
  ) {
    res.status(400).json({ error: "Wallpaper must be a supported key or owned upload" });
    return;
  }
  if (
    data.avatarUrl !== undefined &&
    data.avatarUrl !== "" &&
    !(await ownedImage(athlete.id, data.avatarUrl, "avatar"))
  ) {
    res.status(400).json({ error: "Avatar must be an owned upload" });
    return;
  }
  if (data.accent !== undefined && !isValidAccent(data.accent)) {
    res.status(400).json({ error: "Unsupported accent" });
    return;
  }
  if (
    data.favoriteQuotes !== undefined &&
    data.favoriteQuotes.some(
      (quoteId) => !mindsetQuotes.some((quote) => quote.id === quoteId),
    )
  ) {
    res.status(400).json({ error: "Unknown mindset quote" });
    return;
  }

  await db.transaction(async (tx) => {
    const { favoriteQuotes, ...athleteUpdate } = data;
    if (Object.keys(athleteUpdate).length > 0) {
      await tx
        .update(athletesTable)
        .set(athleteUpdate)
        .where(eq(athletesTable.id, athlete.id));
    }
    if (favoriteQuotes !== undefined) {
      await tx
        .delete(mindsetFavoritesTable)
        .where(eq(mindsetFavoritesTable.athleteId, athlete.id));
      const uniqueQuoteIds = [...new Set(favoriteQuotes)];
      if (uniqueQuoteIds.length > 0) {
        await tx.insert(mindsetFavoritesTable).values(
          uniqueQuoteIds.map((quoteId) => ({
            athleteId: athlete.id,
            quoteId,
          })),
        );
      }
    }
  });

  const [updated] = await db
    .select()
    .from(athletesTable)
    .where(eq(athletesTable.id, athlete.id));
  res.json(UpdatePersonalizationResponse.parse(await personalizationFor(updated)));
});

router.post(
  "/personalization/upload",
  uploadImageMiddleware,
  async (req, res): Promise<void> => {
    const file = req.file;
    if (!file || !file.buffer || file.size > MAX_IMAGE_BYTES) {
      res.status(400).json({ error: "An image file is required" });
      return;
    }
    const parsed = UploadPersonalizationImageBody.safeParse({
      file: new Blob(),
      kind: req.body.kind,
    });
    if (!parsed.success) {
      res.status(400).json({ error: "kind must be wallpaper or avatar" });
      return;
    }
    const contentType = detectImageContentType(file.buffer);
    if (!contentType) {
      res.status(415).json({ error: "Only JPEG, PNG, and WebP images are supported" });
      return;
    }
    const athlete = await currentAthlete(req);
    const id = randomUUID();
    try {
      const objectPath = await objectStorageService.uploadObjectEntity({
        id,
        data: file.buffer,
        contentType,
      });
      await db.insert(personalizationImagesTable).values({
        id,
        athleteId: athlete.id,
        kind: parsed.data.kind,
        objectPath,
        contentType,
        size: file.size,
      });
      res.json(
        UploadPersonalizationImageResponse.parse({
          url: `/api/personalization/images/${id}`,
        }),
      );
    } catch (error) {
      req.log.error({ err: error, athleteId: athlete.id }, "Personalization image upload failed");
      res.status(500).json({ error: "Failed to store image" });
    }
  },
);

router.get("/personalization/images/:id", async (req, res): Promise<void> => {
  const params = GetPersonalizationImageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const athlete = await currentAthlete(req);
  const [image] = await db
    .select()
    .from(personalizationImagesTable)
    .where(
      and(
        eq(personalizationImagesTable.id, params.data.id),
        eq(personalizationImagesTable.athleteId, athlete.id),
      ),
    )
    .limit(1);
  if (!image) {
    res.status(404).json({ error: "Image not found" });
    return;
  }
  try {
    const objectFile = await objectStorageService.getObjectEntityFile(image.objectPath);
    const response = await objectStorageService.downloadObject(objectFile);
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    res.setHeader("Content-Type", image.contentType);
    res.setHeader("Cache-Control", "private, max-age=3600");
    if (response.body) {
      Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Image not found" });
      return;
    }
    req.log.error({ err: error, imageId: image.id }, "Personalization image serve failed");
    res.status(500).json({ error: "Failed to serve image" });
  }
});

router.get("/mindset", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  const quote = dailyMindsetQuote();
  const result = await quoteWithFavorite(athlete.id, quote.id);
  res.json(GetMindsetResponse.parse(result));
});

router.get("/mindset/favorites", async (req, res): Promise<void> => {
  const athlete = await currentAthlete(req);
  const ids = await favoriteQuoteIds(athlete.id);
  const favorites = await Promise.all(
    ids.map((quoteId) => quoteWithFavorite(athlete.id, quoteId)),
  );
  res.json(ListMindsetFavoritesResponse.parse(favorites.filter(Boolean)));
});

router.put("/mindset/favorites/:quoteId", async (req, res): Promise<void> => {
  const params = SetMindsetFavoriteParams.safeParse(req.params);
  const body = SetMindsetFavoriteBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  if (!mindsetQuotes.some((quote) => quote.id === params.data.quoteId)) {
    res.status(404).json({ error: "Mindset quote not found" });
    return;
  }
  const athlete = await currentAthlete(req);
  if (body.data.favorited) {
    await db
      .insert(mindsetFavoritesTable)
      .values({ athleteId: athlete.id, quoteId: params.data.quoteId })
      .onConflictDoNothing();
  } else {
    await db
      .delete(mindsetFavoritesTable)
      .where(
        and(
          eq(mindsetFavoritesTable.athleteId, athlete.id),
          eq(mindsetFavoritesTable.quoteId, params.data.quoteId),
        ),
      );
  }
  const result = await quoteWithFavorite(athlete.id, params.data.quoteId);
  res.json(SetMindsetFavoriteResponse.parse(result));
});

export default router;