---
name: Athlete-first product sequencing
description: Why NEXTREP should deepen the athlete experience before expanding to other account roles.
---

Build the first complete product around the athlete’s daily loop: discover training, complete work, see improvement, and present recruiting progress. Add coach, parent, team, and recruiter interfaces as distinct later phases rather than mixing their controls into the athlete workspace.

**Why:** The product brief spans several audiences and could become difficult to use if every role is implemented in one shared interface before the core training loop is proven.

**How to apply:** New first-release features should strengthen training, progress, competition, or recruiting for athletes. Role-specific management tools should get their own navigation and authorization boundaries.