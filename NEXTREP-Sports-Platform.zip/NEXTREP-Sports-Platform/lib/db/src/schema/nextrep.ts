import {
  boolean,
  doublePrecision,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const athletesTable = pgTable(
  "athletes",
  {
  id: serial("id").primaryKey(),
  clerkUserId: text("clerk_user_id"),
  name: text("name").notNull(),
  firstName: text("first_name").notNull(),
  sport: text("sport").notNull(),
  position: text("position").notNull(),
  graduationYear: integer("graduation_year").notNull(),
  height: text("height").notNull(),
  weight: text("weight").notNull(),
  school: text("school").notNull(),
  location: text("location").notNull(),
  gpa: doublePrecision("gpa").notNull(),
  repScore: integer("rep_score").notNull().default(84),
  xp: integer("xp").notNull().default(2450),
  level: integer("level").notNull().default(12),
  streak: integer("streak").notNull().default(12),
  workoutsCompleted: integer("workouts_completed").notNull().default(47),
  avatarUrl: text("avatar_url").notNull().default(""),
  wallpaper: text("wallpaper").notNull().default("nextrep-blue"),
  accent: text("accent").notNull().default("#89CFF0"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
  },
  (table) => ({
    clerkUserIdUnique: uniqueIndex("athletes_clerk_user_id_unique").on(
      table.clerkUserId,
    ),
  }),
);

export const trainingVideosTable = pgTable("training_videos", {
  id: serial("id").primaryKey(),
  coach: text("coach").notNull(),
  coachInitials: text("coach_initials").notNull(),
  verified: boolean("verified").notNull().default(false),
  drillName: text("drill_name").notNull(),
  sport: text("sport").notNull(),
  position: text("position").notNull(),
  difficulty: text("difficulty").notNull(),
  duration: text("duration").notNull(),
  likes: integer("likes").notNull().default(0),
  comments: integer("comments").notNull().default(0),
  saves: integer("saves").notNull().default(0),
  shares: integer("shares").notNull().default(0),
  liked: boolean("liked").notNull().default(false),
  saved: boolean("saved").notNull().default(false),
  thumbnailUrl: text("thumbnail_url").notNull().default(""),
  gradient: text("gradient").notNull(),
});

export const workoutItemsTable = pgTable("workout_items", {
  id: serial("id").primaryKey(),
  athleteId: integer("athlete_id").references(() => athletesTable.id),
  videoId: integer("video_id").references(() => trainingVideosTable.id),
  title: text("title").notNull(),
  duration: text("duration").notNull(),
  status: text("status").notNull().default("scheduled"),
  scheduledDate: text("scheduled_date").notNull(),
  xpEarned: integer("xp_earned").notNull().default(0),
  completionRepScore: integer("completion_rep_score"),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const coachMessagesTable = pgTable("coach_messages", {
  id: serial("id").primaryKey(),
  athleteId: integer("athlete_id").references(() => athletesTable.id),
  role: text("role").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const athleteVideoReactionsTable = pgTable(
  "athlete_video_reactions",
  {
    id: serial("id").primaryKey(),
    athleteId: integer("athlete_id")
      .notNull()
      .references(() => athletesTable.id),
    videoId: integer("video_id")
      .notNull()
      .references(() => trainingVideosTable.id),
    liked: boolean("liked").notNull().default(false),
    saved: boolean("saved").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    athleteVideoUnique: uniqueIndex(
      "athlete_video_reactions_athlete_video_unique",
    ).on(table.athleteId, table.videoId),
  }),
);

export const mindsetFavoritesTable = pgTable(
  "mindset_favorites",
  {
    id: serial("id").primaryKey(),
    athleteId: integer("athlete_id")
      .notNull()
      .references(() => athletesTable.id),
    quoteId: text("quote_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    athleteQuoteUnique: uniqueIndex("mindset_favorites_athlete_quote_unique").on(
      table.athleteId,
      table.quoteId,
    ),
  }),
);

export const personalizationImagesTable = pgTable("personalization_images", {
  id: text("id").primaryKey(),
  athleteId: integer("athlete_id")
    .notNull()
    .references(() => athletesTable.id),
  kind: text("kind").notNull(),
  objectPath: text("object_path").notNull(),
  contentType: text("content_type").notNull(),
  size: integer("size").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const insertAthleteSchema = createInsertSchema(athletesTable).omit({
  id: true,
  updatedAt: true,
});
export const insertTrainingVideoSchema = createInsertSchema(
  trainingVideosTable,
).omit({ id: true });
export const insertWorkoutItemSchema = createInsertSchema(
  workoutItemsTable,
).omit({ id: true, createdAt: true });
export const insertCoachMessageSchema = createInsertSchema(
  coachMessagesTable,
).omit({ id: true, createdAt: true });
export const insertAthleteVideoReactionSchema = createInsertSchema(
  athleteVideoReactionsTable,
).omit({ id: true, updatedAt: true });
export const insertMindsetFavoriteSchema = createInsertSchema(
  mindsetFavoritesTable,
).omit({ id: true, createdAt: true });
export const insertPersonalizationImageSchema = createInsertSchema(
  personalizationImagesTable,
).omit({ createdAt: true });

export type Athlete = typeof athletesTable.$inferSelect;
export type TrainingVideo = typeof trainingVideosTable.$inferSelect;
export type WorkoutItem = typeof workoutItemsTable.$inferSelect;
export type CoachMessage = typeof coachMessagesTable.$inferSelect;
export type AthleteVideoReaction = typeof athleteVideoReactionsTable.$inferSelect;
export type MindsetFavorite = typeof mindsetFavoritesTable.$inferSelect;
export type PersonalizationImage =
  typeof personalizationImagesTable.$inferSelect;
export type InsertAthlete = z.infer<typeof insertAthleteSchema>;
export type InsertTrainingVideo = z.infer<typeof insertTrainingVideoSchema>;
export type InsertWorkoutItem = z.infer<typeof insertWorkoutItemSchema>;
export type InsertCoachMessage = z.infer<typeof insertCoachMessageSchema>;
export type InsertAthleteVideoReaction = z.infer<
  typeof insertAthleteVideoReactionSchema
>;
export type InsertMindsetFavorite = z.infer<typeof insertMindsetFavoriteSchema>;
export type InsertPersonalizationImage = z.infer<
  typeof insertPersonalizationImageSchema
>;